.inner_block{
    background: #fff;
    margin: 0 10px;
    max-height: 440px;
    overflow-y: scroll;
}
.inner_wrapper{
    padding: 10px;
}
.slds-col{
    cursor: pointer;
    margin-left: 10px;
}
.slds-size_1-of-3{
    width: 20% !important;
}
.slds-size_2-of-3{
    width: 79% !important;
}

.main_block{
    position: relative;
    width: 100%;
    height: 800px;
}
.table_caption{
    background: rgba(176, 196, 223, 1.0);
    height: 20px;
}
.select_width{
    width: 100%;
}

.bPageBlock .detailList .dataCol{
    width: 100% !important;
}

.tab_height{
    height: 740px;
}

.slds-dueling-list__column{
    width: 100%;
}

.slds-modal__container{
    width: 80% !important;
}
.margin_left{
    margin-left: 25px;
}
.margin_top{
    margin-top: 65px;
}
.slds-button{
    cursor: pointer;
    width: 100%;
}
.slds-scope .slds-dueling-list__options, .slds-scope .slds-picklist__options{
    height: 25rem;
}
